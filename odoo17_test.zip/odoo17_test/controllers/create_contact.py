# controllers/main.py
from odoo import http
from odoo.http import request
import json

class ContactsController(http.Controller):

    @http.route('/create_custom_contact', type='http', auth='public', methods=['POST'], csrf=False)
    def add_contact(self, **post):
        try:
            data = json.loads(request.httprequest.data.decode('utf-8'))
        except json.JSONDecodeError:
            return http.Response("Invalid JSON data", status=400)

        name = data.get('name')
        phone = data.get('phone')
        email = data.get('email')
        address = data.get('address', {})

        if not name or not phone or not email:
            return http.Response("Name, phone, and email are required fields", status=400)
        state_id = request.env['res.country.state'].search([('name','ilike',address.get('state', ''))],limit=1)
        contact_vals = {
            'name': name,
            'phone': phone,
            'email': email,
            'street': address.get('street', ''),
            'city': address.get('city', ''),
            'zip': address.get('zip', ''),
            'state_id': state_id and state_id.id or False,
            'country_id': state_id and state_id.country_id and state_id.country_id.id or False,
        }

        contact = request.env['res.partner'].sudo().create(contact_vals)

        return http.Response(f"Contact {contact.name} created successfully", status=201)
