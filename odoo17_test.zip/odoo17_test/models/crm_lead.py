# In your custom module, create a file named 'models.py'
from odoo import models, fields
from odoo import api

class CrmOpportunity(models.Model):
    _name = 'crm.opportunity'
    _description = 'Opportunity'

    lead_id= fields.Many2one('crm.lead', string='Lead')
    opportunity_type = fields.Selection([
        ('technology', 'Technology'),
        ('business', 'Business'),
    ], string='Opportunity Type')
    # Add other fields as needed


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    opportunity_type = fields.Selection([
        ('technology', 'Technology'),
        ('business', 'Business'),
    ], string='Opportunity Type')


    opportunity_ids = fields.One2many('crm.opportunity', 'lead_id', string='Opportunities',
                                          groups="base.group_user")

    stage_id = fields.Many2one('crm.stage', string='Stage', ondelete='restrict',
                               track_visibility='onchange', index=True,
                               domain="['|', ('team_id', '=', False), ('team_id', '=', team_id)]",
                               group_expand="_read_group_stage_ids")

    _sql_constraints = [
        ('stage_uniq', 'unique(lead_id, stage_id)', 'A lead can only be in one stage at a time!')
    ]

    @api.model
    def create(self, values):

        lead = super(CrmLead, self).create(values)

        complete_stage_id = self.env.ref(
            'odoo17_test.stage_lead_complete').id
        if lead.stage_id.id == complete_stage_id:
            opportunity_values = {
                'name': lead.name,
                'partner_id': lead.partner_id.id,
                'type': lead.opportunity_type,
            }
            opportunity = self.env['crm.opportunity'].create(opportunity_values)
            lead.write({'opportunity_ids': [(4, opportunity.id)]})

        return lead