# -*- coding: utf-8 -*-
{
    'name': 'Many2Many Tags - Multi Select with Checkbox Option',
    'version': '17.0.0.1.0',
    'category': 'Tools',
    'summary': 'Add the checkbox in the many2many dropdown for every value so the user can select\n'
                    'multiple values and save them in a single shot. (vice versa)',
    'description': 'Add the checkbox in the many2many dropdown for every value so the user can select\n'
                    'multiple values and save them in a single shot. (vice versa)',
    'author': 'DP',
    'website': '',
    'depends': ['web','crm'],
    'data': [
        'security/ir.model.access.csv',
        'views/crm_lead_views.xml',
    ],
    'images': ['static/description/banner.png'],
    'assets': {
        'web.assets_backend': [
            'odoo17_test/static/src/js/many2many_tags_multi_select.js',
            'odoo17_test/static/src/xml/autocomplete_inherited.xml',
            'odoo17_test/static/src/xml/many2many_tags_inherited.xml'
            # 'opsway-2many-clickable-tag/static/src/js/tags_list.js',
            # 'opsway-2many-clickable-tag/static/src/js/tags_list.xml',
        ],
    },
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}